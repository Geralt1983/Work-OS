import { WorkOS } from "@/components/work-os"

export default function Home() {
  return <WorkOS />
}
